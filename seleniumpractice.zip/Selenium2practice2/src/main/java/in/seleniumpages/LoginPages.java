package in.seleniumpages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPages {
    private WebDriver driver;

    @FindBy(partialLinkText = "Log in")
    private WebElement logInBtn;
    
    @FindBy(id = "Email")
    private WebElement emailTextBox;
    
    @FindBy(id = "Password")
    private WebElement passwordTextBox;
    
    @FindBy(xpath = "//input[@value='Log in']")
    private WebElement loginButton;
    @FindBy(linkText = "Log out")
    private WebElement logOutButton;

    public LoginPages(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void clickOnLogin() {
        logInBtn.click();
    }

    public void enterEmail(String email) {
        emailTextBox.clear();
        emailTextBox.sendKeys(email);
    }

    public void enterPassword(String password) {
        passwordTextBox.clear();
        passwordTextBox.sendKeys(password);
    }

    public void clickLoginButton() {
        loginButton.click();
    }
    public void clickLogOutBtn() {
    	logOutButton.click();
    }
    
}
