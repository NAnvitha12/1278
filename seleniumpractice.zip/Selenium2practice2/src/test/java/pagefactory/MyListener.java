package pagefactory;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class MyListener implements ITestListener {
	private ExtentReports extent;
	private ExtentTest test;
	private WebDriver driver;
	ScreenShotUtility s;

	@Override
	public void onTestStart(ITestResult result) {
		System.out.println("TestCase Started");

		test.log(LogStatus.INFO, result.getMethod().getMethodName());

	}

	@Override
	public void onTestSuccess(ITestResult result) {
		System.out.println("TestCase Success");
		test.log(LogStatus.PASS, "TestCase Success"); 
	}

	@Override
	public void onTestFailure(ITestResult result) {
	    System.out.println("TestCase failure");
	   // test.log(LogStatus.FAIL, result.getMethod().getMethodName());

	    try {
	        test.log(LogStatus.FAIL, "ScreenShot" + test.addScreenCapture(s.takeScreenshot())); // Log test failure with screenshot
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}


	@Override
	public void onTestSkipped(ITestResult result) {
		System.out.println("TestCase Skipped");
		test.log(LogStatus.SKIP, result.getMethod().getMethodName()); // Log test skip status
	}

	@Override
	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
	}

	@Override
	public void onStart(ITestContext context) {
		s=new ScreenShotUtility();
		System.out.println("TestNg Started");
		extent = new ExtentReports("test-output/MyReport.html", true);
		//test = extent.startTest("LogInTest Started");
		extent.addSystemInfo("Browser", "Chrome");
		extent.addSystemInfo("Build", "Smoke Testing");
	}

	@Override
	public void onFinish(ITestContext context) {
		System.out.println("TestNg finished");
		extent.flush(); // Flush the report to save it
	}
}
