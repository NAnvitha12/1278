package pagefactory;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;

public class ExcelRead {
    XSSFWorkbook file;
    XSSFSheet s;

    public String readExcel(String path, String sheetName, int r, int c) throws IOException {
        FileInputStream fin = new FileInputStream(path);
        file = new XSSFWorkbook(fin);
        s = file.getSheet(sheetName);
        String data = s.getRow(r).getCell(c).getStringCellValue();
        fin.close();
        return data;
    }

    public int getLastRow(String path, String sheetName) throws IOException {
        FileInputStream fin = new FileInputStream(path);
        file = new XSSFWorkbook(fin);
        s = file.getSheet(sheetName);
        int lastRow = s.getLastRowNum();
        fin.close();
        return lastRow;
    }

    public static void main(String[] args) throws IOException {
        ExcelRead e = new ExcelRead();
        int lastRow = e.getLastRow("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1");
        System.out.println("Last row number: " + lastRow);

        for (int i = 0; i <= lastRow; i++) {
            String Username = e.readExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1", i, 0);
            String Password = e.readExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1", i, 1);

            System.out.print("Username" + i + " " + Username + " ");
            System.out.println("Password" + i + " " + Password + " ");
            System.out.println("");
        }
    }
}
