package pagefactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelwrite {
	XSSFWorkbook file;
	XSSFSheet s;

	public void WriteExcel(String path, String sheetName, int r, int c, String result) throws IOException {
		FileInputStream fin = new FileInputStream(path);
		file = new XSSFWorkbook(fin);
		s = file.getSheet(sheetName);
		s.getRow(r).createCell(c).setCellValue(result);

		FileOutputStream fout = new FileOutputStream(path);

		s = file.getSheet(sheetName);
		file.write(fout);
		fout.flush();
		file.close();

	}

	public static void main(String[] args) throws IOException {
		Excelwrite e = new Excelwrite();
		e.WriteExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1", 0, 2, "Pass");
		/*
		 * for (int i = 0; i <= lastRow; i++) { String Username =
		 * e.readExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1", i, 0);
		 * String Password = e.readExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx",
		 * "Sheet1", i, 1);
		 * 
		 * System.out.print("Username" + i + " " + Username + " ");
		 * System.out.println("Password" + i + " " + Password + " ");
		 * System.out.println(""); }
		 */
	}
}
