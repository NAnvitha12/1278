package in.seleniumtestscripts;

import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import in.seleniumpages.LoginPages;
import pagefactory.ExcelRead;
import pagefactory.MyListener;
import pagefactory.TestBase;

@Listeners(value= {MyListener.class})
public class LoginTest extends TestBase {
	ExcelRead e = new ExcelRead();

	@DataProvider
	public Object[][] loginData() throws IOException {
		int lastRow = e.getLastRow("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1");

		Object[][] Mydata = new Object[lastRow + 1][2];
		for (int i = 0; i <= lastRow; i++) {
			Mydata[i][0] = e.readExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1", i, 0);
			Mydata[i][1] = e.readExcel("C:\\Users\\anji\\Downloads\\excel data.xlsx", "Sheet1", i, 1);

		}
		return Mydata;

	}

	@Test(dataProvider = "loginData", priority = 1)
	public void testLogin(String Username, String Password) {
		LoginPages loginPages = new LoginPages(driver);

		loginPages.clickOnLogin();
		loginPages.enterEmail(Username);
		loginPages.enterPassword(Password);
		loginPages.clickLoginButton();
		

		// Add assertions or validations for successful login here.
	}

}
