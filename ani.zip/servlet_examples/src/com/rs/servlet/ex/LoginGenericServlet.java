package com.rs.servlet.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/loginGS")
public class LoginGenericServlet extends GenericServlet {

	int loginHitsCount;

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("LoginGenericServlet.init()");
		loginHitsCount = 0;
	}

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("LoginGenericServlet.service()");

		// 1.inputs
		String username = request.getParameter("userName");
		String password = request.getParameter("password");

		// 2.business logic
		boolean isValidUser = false;
		if ("admin".equals(username) && "admin".equals(password)) {
			isValidUser = true;
		}

		// 3.
		PrintWriter out = response.getWriter();
		if (isValidUser) {
			out.println("welcome to the user:" + username);
		} else {
			out.println("incorrect username/password.please try again later...!!!!!!");
		}

		loginHitsCount++;
		out.println("loginHitsCount:" + loginHitsCount);

		System.out.println("***********");
	}

	@Override
	public void destroy() {
		System.out.println("LoginGenericServlet.destroy()");

		loginHitsCount = 0;

	}

}
