
package com.rs.servlet.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/login")
public class LoginServlet implements Servlet {

	int loginHitsCount;

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Loginservlet.init()");
		loginHitsCount = 0;
	}

	@Override
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("Loginservlet.service()");

		// 1.inputs
		String username = request.getParameter("userName");
		String password = request.getParameter("password");

		// 2.business logic
		boolean isValidUser = false;
		if ("admin".equals(username) && "admin".equals(password)) {
			isValidUser = true;
		}

		// 3.
		PrintWriter out = response.getWriter();
		if (isValidUser) {
			out.println("welcome to the user:" + username);
		} else {
			out.println("incorrect username/password.please try again later...!!!!!!");
		}

		loginHitsCount++;
		out.println("loginHitsCount:" + loginHitsCount);

		System.out.println("***********");
	}

	@Override
	public void destroy() {
		System.out.println("Loginservlet.destroy()");

		loginHitsCount = 0;

	}

	@Override
	public ServletConfig getServletConfig() {
		System.out.println("Loginservlet.getServletConfig()");

		return null;
	}

	@Override
	public String getServletInfo() {
		System.out.println("Loginservlet.getServletInfo()");

		return null;
	}

}
