package com.rs.servlet.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/loginHS")
public class LoginHttpServlet extends HttpServlet {

	int loginHitsCount = 0;

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("LoginHttpServlet.doGet()");

		// 1.inputs
		String username = request.getParameter("userName");
		String password = request.getParameter("password");

		// 2.business logic
		boolean isValidUser = false;
		if ("admin".equals(username) && "admin".equals(password)) {
			isValidUser = true;
		}

		// 3.
		PrintWriter out = response.getWriter();
		if (isValidUser) {
			out.println("welcome to the user:" + username);
		} else {
			out.println("incorrect username/password.please try again later...!!!!!!");
		}

		loginHitsCount++;
		out.println("loginHitsCount:" + loginHitsCount);

		System.out.println("***********");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		System.out.println("LoginHttpServlet.doPost()");

		// 1.inputs
		String username = request.getParameter("userName");
		String password = request.getParameter("password");

		// 2.business logic
		boolean isValidUser = false;
		if ("admin".equals(username) && "admin".equals(password)) {
			isValidUser = true;
			// RequestDispatcher requestDispatcher =
			// request.getRequestDispatcher("DashBoard.html");
			// requestDispatcher.forward(request, response);
			response.sendRedirect("DashBoard.html");
		}

		// 3.
		PrintWriter out = response.getWriter();
		if (isValidUser) {
			out.println("welcome to the user:" + username);
		} else {
			out.println("incorrect username/password.please try again later...!!!!!!");

			RequestDispatcher requestDispatcher = request.getRequestDispatcher("Login.html");
			requestDispatcher.include(request, response);
			// requestDispatcher.forward(request, response);--only forwarding o/p page will
			// display
		}

		loginHitsCount++;
		out.println("loginHitsCount:" + loginHitsCount);

		System.out.println("***********");

	}

}
