package com.rs.servlet.userstate.session.ex;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/ContactInfoS")
public class ContactInfoServlet extends HttpServlet {
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("ContactInfoServlet::init()");
		
		String configValue=config.getInitParameter("pageTitle");
		System.out.println("  ContactInfoServlet::Config Value:"+configValue);
		
		ServletContext context=config.getServletContext();
		String contextValue=context.getInitParameter("appTitle");
		System.out.println("ContactInfoServlet::Context Value:"+contextValue);
		
		System.out.println("..............................................");
	}


	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String fullname = request.getParameter("fullname");

		System.out.println("ContactInfoServlet:: fullname:" + fullname);

		String mobile = request.getParameter("mobile");
		System.out.println("ContactInfoServlet:: mobile:" + mobile);

		System.out.println("******************");

		HttpSession session = request.getSession();
		session.setAttribute("mobile", mobile);

		response.sendRedirect("AddressInfo.html");
	}

}
