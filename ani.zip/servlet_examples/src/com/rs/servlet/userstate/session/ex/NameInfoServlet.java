package com.rs.servlet.userstate.session.ex;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/NameInfoS")
public class NameInfoServlet extends HttpServlet {
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("NameInfoServlet::init()");
		
		String configValue=config.getInitParameter("pageTitle");
		System.out.println(" NameInfoServlet::Config Value:"+configValue);
		
		ServletContext context=config.getServletContext();
		String contextValue=context.getInitParameter("appTitle");
		System.out.println(" NameInfoServlet::Context Value:"+contextValue);
		
		System.out.println("..............................................");
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String fullname = request.getParameter("fullname");

		System.out.println("NameInfoServlet:: fullname:" + fullname);

		System.out.println("******************");

		HttpSession session = request.getSession();
		session.setAttribute("fullname", fullname);

		response.sendRedirect("ContactInfo.html");
	}

}
