package com.rs.servlet.userstate.cookie.ex;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/NameInfoC")
public class NameInfoServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String fullname = request.getParameter("fullname");

		System.out.println("NameInfoServlet:: fullname:" + fullname);

		System.out.println("******************");

		Cookie cookie = new Cookie("fullname", fullname);
		response.addCookie(cookie);

		response.sendRedirect("ContactInfo.html");
	}

}
