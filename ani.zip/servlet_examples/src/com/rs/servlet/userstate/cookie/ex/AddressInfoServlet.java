package com.rs.servlet.userstate.cookie.ex;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/AddressInfoC")
public class AddressInfoServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Cookie[] cookieArray = request.getCookies();

		String fullname = cookieArray[0].getValue();

		System.out.println("AddressInfoServlet:: fullname:" + fullname);

		String mobile = cookieArray[1].getValue();

		System.out.println("AddressInfoServlet:: mobile:" + mobile);

		String city = request.getParameter("city");
		System.out.println("AddressInfoServlet:: city:" + city);

		System.out.println("******************");

		PrintWriter out = response.getWriter();
		out.println("Review Update Profile");
		out.println("<BR>");

		out.println("Full Name:" + fullname);
		out.println("<BR>");

		out.println("Mobile:" + mobile);
		out.println("<BR>");

		out.println("City:" + city);

	}

}
